from django.apps import AppConfig


class GrafikNavchannyaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'grafik_navchannya'

from django.contrib import admin
from .models import Rozklad

# Register your models here.
admin.site.register(Rozklad)
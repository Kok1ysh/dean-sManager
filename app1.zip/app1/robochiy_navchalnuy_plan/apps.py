from django.apps import AppConfig


class RobochiyNavchalnuyPlanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'robochiy_navchalnuy_plan'

from django.contrib import admin

from .models import RobochiyNavchalnuyPlan, ElementRNP


admin.site.register(RobochiyNavchalnuyPlan)
admin.site.register(ElementRNP)

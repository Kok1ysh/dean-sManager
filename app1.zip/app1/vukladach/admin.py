from django.contrib import admin

from .models import Vukladach


admin.site.register(Vukladach)

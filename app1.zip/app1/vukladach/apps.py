from django.apps import AppConfig


class VukladachConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vukladach'

from django.contrib import admin

from .models import *


admin.site.register(EducationalPrograms)
admin.site.register(FormaKontrolus)
admin.site.register(KomponentEducationalPrograms)

from django.contrib import admin
from .models import Facultys,Kafedras


admin.site.register(Facultys)
admin.site.register(Kafedras)
